console.log("move js");

let buttonStart   = document.getElementById("btnStart"),       // кнопка старту гри
    containerGame = document.querySelector(".game-container"); // контейнер куди будемо генерувати ворогів

// Функція для визначення нових координат
function makeNewPosition(){
	
    // Отримуємо розміри вікна браузеру
    let height    = window.innerHeight - 50,
        width     = window.innerWidth - 50,
		newHeight = Math.floor(Math.random() * height), // Метод Math.random() повертає псевдовипадкове число з плаваючою комою в діапазоні [0, 1).
        newWidth  = Math.floor(Math.random() * width);  // Метод Math.floor() - округлення вниз. Округляє аргумент до найближчого меншого цілого.
    
    return [newHeight, newWidth]; // функція повертає массив з двома змінними: висота та довжина. Це нові координати.   
}

