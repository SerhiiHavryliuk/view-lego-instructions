console.log("game js");

let gameContainer = document.querySelector(".game-container"),// контейнер куди будемо генерувати ворогів
    musicShot     = document.querySelector('.shot'), 		  // музикальний файл пострілу
    musicHit      = document.querySelector('.hit'),           // музикальний файл влучання пулі
    textScore     = document.querySelector('.count strong'),  // поле в якому будемо відображати кількість влучань
    textBullet    = document.querySelector('.bullet strong'), // поле в якому будемо відображати поточну кількість куль
    imgGameOver   = document.querySelector(".gameOver"),      // картика програшу у грі
    imgGameWin    = document.querySelector(".gameWin"),       // картинка перемоги у грі
    score         = 0,                                        // кількість потраплянь у ворога
    bullet        = 5;                                        // кількість патронів

// Функція для пострілів.
// При кожному пострілі створюється новий прототип програвання звукового файлу.
HTMLAudioElement.prototype.stop = function(){
 this.pause();
 this.currentTime = 0.0;
}

