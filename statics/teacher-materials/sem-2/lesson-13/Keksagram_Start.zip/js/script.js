let img =  $( ".images img" );

// Зображення 1 в ряд
$( "#btn_one" ).click(function(event) {
    console.log(event);
    img.addClass( "filter_one_img" );
});
  
// Зображення 3 в ряд
$( "#btn_all" ).click(function(event) {
    console.log(event);
    img.removeClass( "filter_one_img" );
});